<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Produk_model extends CI_Model
{
    public function count_all()
    {
        return $this->db->count_all('produk');
    }

    public function get_all()
    {
        return $this->db->get('produk')->result();
    }

    public function get_by_id($id)
    {
        return $this->db->get_where('produk', ['id_produk' => $id])->row();
    }
}
