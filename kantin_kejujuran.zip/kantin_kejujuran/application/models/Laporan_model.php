<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan_model extends CI_Model
{
    public function get_all()
    {
        $this->db->select('
            transaksi.id_transaksi,
            transaksi.tanggal,
            transaksi.total,
            transaksi.id_user,
            transaksi_detail.jumlah,
            transaksi_detail.subtotal,
            produk.nama_produk
        ');
        $this->db->from('transaksi');
        $this->db->join('transaksi_detail', 'transaksi.id_transaksi = transaksi_detail.id_transaksi');
        $this->db->join('produk', 'produk.id_produk = transaksi_detail.id_produk');
        $this->db->order_by('transaksi.tanggal', 'DESC');
        return $this->db->get()->result();
    }

    public function get_by_id($id_transaksi)
    {
        $this->db->select('
            transaksi.id_transaksi,
            transaksi.tanggal,
            transaksi.total,
            transaksi.id_user,
            transaksi_detail.jumlah,
            transaksi_detail.harga,
            transaksi_detail.subtotal,
            produk.nama_produk
        ');
        $this->db->from('transaksi');
        $this->db->join('transaksi_detail', 'transaksi.id_transaksi = transaksi_detail.id_transaksi');
        $this->db->join('produk', 'produk.id_produk = transaksi_detail.id_produk');
        $this->db->where('transaksi.id_transaksi', $id_transaksi);
        return $this->db->get()->result();
    }

    public function get_by_date_range($start_date, $end_date)
    {
        $this->db->select('
            transaksi.id_transaksi,
            transaksi.tanggal,
            transaksi.total,
            transaksi_detail.jumlah,
            transaksi_detail.subtotal,
            produk.nama_produk
        ');
        $this->db->from('transaksi');
        $this->db->join('transaksi_detail', 'transaksi.id_transaksi = transaksi_detail.id_transaksi');
        $this->db->join('produk', 'produk.id_produk = transaksi_detail.id_produk');
        $this->db->where('DATE(transaksi.tanggal) >=', $start_date);
        $this->db->where('DATE(transaksi.tanggal) <=', $end_date);
        $this->db->order_by('transaksi.tanggal', 'DESC');
        return $this->db->get()->result();
    }

    public function get_last_id_transaksi()
    {
        $this->db->select_max('id_transaksi');
        $result = $this->db->get('transaksi')->row();
        return $result->id_transaksi ?? 0;
    }

    public function count_all()
    {
        return $this->db->count_all('transaksi');
    }
}
