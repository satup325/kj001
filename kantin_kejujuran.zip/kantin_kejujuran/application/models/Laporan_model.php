<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan_model extends CI_Model
{
    // Ambil semua transaksi selesai
    public function get_all()
    {
        $this->db->select('transaksi.*, transaksi_detail.*, produk.nama_produk');
        $this->db->from('transaksi');
        $this->db->join('transaksi_detail', 'transaksi.id_transaksi = transaksi_detail.id_transaksi');
        $this->db->join('produk', 'produk.id_produk = transaksi_detail.id_produk');
        $this->db->where('transaksi.status', 'selesai');
        $this->db->order_by('transaksi.tanggal', 'DESC');
        return $this->db->get()->result();
    }

    // Ambil transaksi selesai berdasarkan rentang tanggal
    public function get_by_date_range($start_date, $end_date)
    {
        $this->db->select('transaksi.*, transaksi_detail.*, produk.nama_produk');
        $this->db->from('transaksi');
        $this->db->join('transaksi_detail', 'transaksi.id_transaksi = transaksi_detail.id_transaksi');
        $this->db->join('produk', 'produk.id_produk = transaksi_detail.id_produk');
        $this->db->where('transaksi.status', 'selesai');
        $this->db->where('DATE(transaksi.tanggal) >=', $start_date);
        $this->db->where('DATE(transaksi.tanggal) <=', $end_date);
        $this->db->order_by('transaksi.tanggal', 'DESC');
        return $this->db->get()->result();
    }

    // Ambil laporan berdasarkan ID transaksi (jika dibutuhkan)
    public function get_by_id($id_transaksi)
    {
        $this->db->select('transaksi.*, transaksi_detail.*, produk.nama_produk');
        $this->db->from('transaksi');
        $this->db->join('transaksi_detail', 'transaksi.id_transaksi = transaksi_detail.id_transaksi');
        $this->db->join('produk', 'produk.id_produk = transaksi_detail.id_produk');
        $this->db->where('transaksi.id_transaksi', $id_transaksi);
        return $this->db->get()->result();
    }

    // Tambahkan transaksi dan update stok produk
    public function insert_with_update_stok($data)
    {
        // Simpan transaksi
        $this->db->insert('transaksi', [
            'id_user' => $this->session->userdata('id_akun'), // jika tersedia
            'total' => $data['total'],
            'tanggal' => $data['tanggal'],
            'status' => 'selesai'
        ]);

        $id_transaksi = $this->db->insert_id();

        // Simpan detail
        $this->db->insert('transaksi_detail', [
            'id_transaksi' => $id_transaksi,
            'id_produk' => $data['id_produk'],
            'jumlah' => $data['jumlah'],
            'harga' => $data['total'] / $data['jumlah'],
            'subtotal' => $data['total']
        ]);

        // Kurangi stok produk
        $this->db->set('stok', 'stok - ' . (int) $data['jumlah'], false);
        $this->db->where('id_produk', $data['id_produk']);
        $this->db->update('produk');
    }

    public function count_all()
    {
        $this->db->from('transaksi');
        $this->db->where('status', 'selesai');
        return $this->db->count_all_results();
    }
}
