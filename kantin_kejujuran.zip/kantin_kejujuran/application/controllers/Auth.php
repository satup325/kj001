<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(['url', 'form']);
        $this->load->library(['session']);
        $this->load->model('Auth_model');
    }

    public function index()
    {
        redirect('auth/login');
    }

    public function login()
    {
        if ($this->session->userdata('logged_in')) {
            redirect('admin/dashboard');
        }

        if ($this->input->post()) {
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            $user = $this->Auth_model->get_user_by_username($username);

            if ($user && password_verify($password, $user->password)) {
                $this->session->set_userdata([
                    'id_user' => $user->id_user,
                    'username' => $user->username,
                    'role' => $user->role,
                    'logged_in' => true
                ]);
                redirect('admin/dashboard');
            } else {
                $this->session->set_flashdata('error', 'Username atau password salah.');
                redirect('auth/login');
            }
        }

        $this->load->view('auth/login');
    }

    public function register()
    {
        if ($this->input->post()) {
            $password = $this->input->post('password');
            $confirm = $this->input->post('confirm_password');

            if ($password != $confirm) {
                $this->session->set_flashdata('error', 'Konfirmasi password tidak sesuai.');
                redirect('auth/register');
            }

            $data = [
                'username' => $this->input->post('username'),
                'email'    => $this->input->post('email'),
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'role'     => 'user'
            ];

            $this->Auth_model->insert_user($data);
            $this->session->set_flashdata('success', 'Pendaftaran berhasil. Silakan login.');
            redirect('auth/login');
        }

        $this->load->view('auth/register');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('auth/login');
    }
}
