<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Akun_model');
        $this->load->library('session');
        $this->load->helper(array('url', 'form'));
    }

    public function login()
    {
        if ($this->input->post()) {
            $username = $this->input->post('username', TRUE);
            $password = $this->input->post('password', TRUE);

            $akun = $this->Akun_model->get_by_username($username);

            if ($akun && password_verify($password, $akun->password)) {
                $this->session->set_userdata([
                    'id_akun' => $akun->id_akun,
                    'username' => $akun->username,
                    'role' => $akun->role,
                    'logged_in' => TRUE
                ]);
                redirect('dashboard'); // sesuaikan dengan tujuan
            } else {
                $this->session->set_flashdata('error', 'Username atau password salah!');
                redirect('auth/login');
            }
        }

        $this->load->view('auth/login');
    }

    public function register()
    {
        if ($this->input->post()) {
            $username = $this->input->post('username', TRUE);
            $email = $this->input->post('email', TRUE);
            $password = $this->input->post('password');
            $confirm = $this->input->post('confirm_password');

            if ($password !== $confirm) {
                $this->session->set_flashdata('error', 'Konfirmasi password tidak cocok.');
                redirect('auth/register');
            }

            // Cek username/email sudah digunakan
            if ($this->Akun_model->get_by_username($username)) {
                $this->session->set_flashdata('error', 'Username sudah digunakan.');
                redirect('auth/register');
            }

            if ($this->Akun_model->get_by_email($email)) {
                $this->session->set_flashdata('error', 'Email sudah digunakan.');
                redirect('auth/register');
            }

            $data = [
                'username' => $username,
                'email' => $email,
                'password' => password_hash($password, PASSWORD_BCRYPT),
                'role' => 'user'
            ];

            $this->Akun_model->insert($data);
            $this->session->set_flashdata('success', 'Pendaftaran berhasil. Silakan login.');
            redirect('auth/login');
        }

        $this->load->view('auth/register');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('auth/login');
    }
}
