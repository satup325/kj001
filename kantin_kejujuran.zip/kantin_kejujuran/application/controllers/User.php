<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function index()
    {
        $this->load->view('layouts/header');
        $this->load->view('admin/user');
        $this->load->view('layouts/footer');
    }
}
