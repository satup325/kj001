<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function index()
    {
        $data['user'] = $this->User_model->get_all();
        $this->load->view('admin/user/index', $data);
    }

    public function tambah()
    {
        $this->load->view('admin/user/tambah');
    }

    public function store()
    {
        $username = $this->input->post('username', true);
        $email = $this->input->post('email', true);
        $password = $this->input->post('password');
        $password_confirm = $this->input->post('password_confirm');
        $role = $this->input->post('role');

        // Validasi sederhana
        if ($password != $password_confirm) {
            $this->session->set_flashdata('error', 'Password tidak cocok.');
            redirect('admin/user/tambah');
            return;
        }

        $data = [
            'username' => $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => $role
        ];

        $this->User_model->insert($data);

        $this->session->set_flashdata('success', 'User berhasil ditambahkan.');
        redirect('admin/user');
    }
}
