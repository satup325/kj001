<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Produk extends CI_Controller
{
    public function index()
    {
        $data['produk'] = $this->db->get('produk')->result_array();
        $this->load->view('layouts/header');
        $this->load->view('admin/produk', $data);
        $this->load->view('layouts/footer');
    }

    public function tambah()
    {
        $nama   = $this->input->post('nama_produk');
        $besar  = (int) $this->input->post('banyak_satuan_besar');
        $isi    = (int) $this->input->post('isi');
        $harga  = (int) $this->input->post('harga_satuan_besar');

        $harga_eceran = ($isi > 0) ? floor($harga / $isi) : 0;
        $stok         = $besar * $isi;

        $data = [
            'nama_produk'        => $nama,
            'banyak_satuan_besar' => $besar,
            'isi'                => $isi,
            'harga_satuan_besar' => $harga,
            'harga_eceran'       => $harga_eceran,
            'stok'               => $stok
        ];

        $this->db->insert('produk', $data);
        redirect('admin/produk');
    }


    public function edit($id)
    {
        $nama   = $this->input->post('nama_produk');
        $besar  = (int) $this->input->post('banyak_satuan_besar');
        $isi    = (int) $this->input->post('isi');
        $harga  = (int) $this->input->post('harga_satuan_besar');

        $harga_eceran = ($isi > 0) ? floor($harga / $isi) : 0;
        $stok         = $besar * $isi;

        $data = [
            'nama_produk'        => $nama,
            'banyak_satuan_besar' => $besar,
            'isi'                => $isi,
            'harga_satuan_besar' => $harga,
            'harga_eceran'       => $harga_eceran,
            'stok'               => $stok
        ];

        $this->db->where('id_produk', $id);
        $this->db->update('produk', $data);
        redirect('admin/produk');
    }

    public function hapus($id)
    {
        $this->db->delete('produk', ['id_produk' => $id]);
        redirect('admin/produk');
    }
}
