<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->database();
  }

  public function index() {
    $data['users'] = $this->db->get('user')->result_array();
    $this->load->view('admin/user/index', $data);
  }

  public function edit($id) {
    $data['user'] = $this->db->get_where('user', ['id_user' => $id])->row_array();

    if ($this->input->post()) {
      $update = [
        'username' => $this->input->post('username'),
        'email'    => $this->input->post('email'),
        'role'     => $this->input->post('role')
      ];
      $this->db->update('user', $update, ['id_user' => $id]);
      redirect('admin/user');
    }

    $this->load->view('admin/user/edit', $data);
  }

  public function delete($id) {
    $this->db->delete('user', ['id_user' => $id]);
    redirect('admin/user');
  }
}
