<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Keranjang extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        // Cek autentikasi & role
        if (!$this->session->userdata('logged_in') || $this->session->userdata('role') !== 'user') {
            redirect('auth/login');
        }

        // Load model
        $this->load->model('User/Keranjang_model');
        $this->load->model('User/Produk_model');
        $this->load->model('User/Transaksi_model');
    }

    public function index()
    {
        $id_user = $this->session->userdata('id_akun');
        $data['keranjang'] = $this->Keranjang_model->get_by_user($id_user);

        $this->load->view('user/keranjang', $data);
    }

    public function tambah()
    {
        $id_akun   = $this->session->userdata('id_akun');
        $id_produk = $this->input->post('id_produk');
        $jumlah    = $this->input->post('jumlah');

        if (!$id_akun) {
            redirect('auth');
            return;
        }

        if (!$id_produk || !$jumlah) {
            $this->session->set_flashdata('error', 'Produk tidak valid.');
            redirect('user/produk');
            return;
        }

        $item = $this->Keranjang_model->get_item($id_akun, $id_produk);

        $produk = $this->db->get_where('produk', ['id_produk' => $id_produk])->row();

        if ($item) {
            $total = $item->jumlah + $jumlah;
            if ($total > $produk->stok) {
                $total = $produk->stok;
            }
            $this->Keranjang_model->update_jumlah($item->id_keranjang, $total);
        } else {
            if ($jumlah > $produk->stok) {
                $jumlah = $produk->stok;
            }
            $this->Keranjang_model->insert([
                'id_akun'   => $id_akun,
                'id_produk' => $id_produk,
                'jumlah'    => $jumlah,
                'tanggal'   => date('Y-m-d H:i:s')
            ]);
        }


        redirect('user/keranjang');
    }

    public function hapus($id_keranjang)
    {
        $this->Keranjang_model->delete($id_keranjang);
        redirect('user/keranjang');
    }

    public function checkout()
    {
        $id_user = $this->session->userdata('id_akun');
        $keranjang = $this->Keranjang_model->get_by_user($id_user);

        if (empty($keranjang)) {
            redirect('user/keranjang');
        }

        foreach ($keranjang as $item) {
            // Hitung total harga
            $total = $item->harga_jual * $item->jumlah;

            // Simpan transaksi
            $this->Transaksi_model->insert([
                'id_user'   => $id_user,
                'id_produk' => $item->id_produk,
                'jumlah'    => $item->jumlah,
                'total'     => $total,
                'status'    => 'selesai',
                'tanggal'   => date('Y-m-d H:i:s')
            ]);

            // Kurangi stok produk
            $this->Produk_model->kurangi_stok($item->id_produk, $item->jumlah);
        }

        // Hapus isi keranjang setelah checkout
        $this->Keranjang_model->hapus_by_user($id_user);

        // Redirect ke halaman selesai
        redirect('user/selesai');
    }

    public function beli_langsung()
    {
        $id_akun = $this->session->userdata('id_akun');
        if (!$id_akun) {
            redirect('auth');
            return;
        }

        $id_produk = $this->input->post('id_produk');
        $jumlah = (int) $this->input->post('jumlah');

        $produk = $this->db->get_where('produk', ['id_produk' => $id_produk])->row();

        if (!$produk || $jumlah < 1 || $jumlah > $produk->stok) {
            $this->session->set_flashdata('error', 'Produk tidak valid atau jumlah melebihi stok.');
            redirect('user/produk');
            return;
        }

        $subtotal = $produk->harga_jual * $jumlah;

        // Simpan ke tabel transaksi
        $this->db->insert('transaksi', [
            'id_akun'     => $id_akun,
            'tanggal'     => date('Y-m-d H:i:s'),
            'total_harga' => $subtotal
        ]);

        $id_transaksi = $this->db->insert_id();

        // Simpan ke detail_transaksi
        $this->db->insert('detail_transaksi', [
            'id_transaksi' => $id_transaksi,
            'id_produk'    => $id_produk,
            'jumlah'       => $jumlah,
            'subtotal'     => $subtotal
        ]);

        // Kurangi stok produk
        $this->db->set('stok', 'stok - ' . $jumlah, false);
        $this->db->where('id_produk', $id_produk);
        $this->db->update('produk');

        $this->session->set_flashdata('success', 'Pembelian berhasil!');
        redirect('user/selesai'); // halaman selesai transaksi
    }
}
