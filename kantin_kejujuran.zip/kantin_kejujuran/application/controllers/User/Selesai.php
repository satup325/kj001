<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Selesai extends CI_Controller
{
    public function index()
    {
        $id_akun = $this->session->userdata('id_akun');

        if (!$id_akun) {
            redirect('auth');
            return;
        }

        $this->load->model('Transaksi_model');
        $data['transaksi'] = $this->Transaksi_model->get_by_user($id_akun);

        $this->load->view('user/selesai', $data);
    }
}
