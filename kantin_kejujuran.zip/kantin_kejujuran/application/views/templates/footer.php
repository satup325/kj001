  </div> <!-- end of content -->

  <!-- Footer -->
  <footer class="text-center py-3 mt-auto" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(8px);">
      <small>&copy; <?= date('Y') ?> Kantin Kejujuran BPS Kota Gunungsitoli</small>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  </body>

  </html>