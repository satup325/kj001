<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Struk Transaksi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #00c6ff, #0072ff);
            color: #fff;
            padding: 2rem;
        }

        .struk-container {
            max-width: 500px;
            margin: auto;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            border-radius: 1rem;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        h4, h5 {
            text-align: center;
            margin-bottom: 1rem;
        }

        .line {
            border-top: 1px dashed #fff;
            margin: 1rem 0;
        }

        table {
            width: 100%;
        }

        table td {
            padding: 5px 0;
        }

        .text-right {
            text-align: right;
        }

        .btn-print {
            display: block;
            width: 100%;
            margin-top: 1rem;
            background-color: #fff;
            color: #0072ff;
            font-weight: bold;
        }

        .btn-print:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>

<body>

    <div class="struk-container">
        <h4>Kantin Kejujuran</h4>
        <h5>Struk Transaksi</h5>
        <div class="line"></div>

        <table>
            <tr>
                <td>Tanggal</td>
                <td class="text-right"><?= date('d-m-Y H:i', strtotime($transaksi->tanggal ?? 'now')) ?></td>
            </tr>
            <tr>
                <td>ID Transaksi</td>
                <td class="text-right"><?= $transaksi->id_transaksi ?? '-' ?></td>
            </tr>
            <tr>
                <td>User</td>
                <td class="text-right"><?= $user->username ?? '-' ?></td>
            </tr>
        </table>

        <div class="line"></div>

        <table>
            <thead>
                <tr>
                    <td><strong>Produk</strong></td>
                    <td class="text-right"><strong>Subtotal</strong></td>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($detail as $item): ?>
                    <tr>
                        <td><?= $item->nama_produk ?> x<?= $item->jumlah ?></td>
                        <td class="text-right">Rp <?= number_format($item->subtotal, 0, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="line"></div>

        <table>
            <tr>
                <td><strong>Total</strong></td>
                <td class="text-right"><strong>Rp <?= number_format($transaksi->total ?? 0, 0, ',', '.') ?></strong></td>
            </tr>
        </table>

        <div class="line"></div>
        <p class="text-center">Terima kasih telah bertransaksi!</p>

        <button class="btn btn-print btn" onclick="window.print()"><i class="bi bi-printer"></i> Cetak</button>
    </div>

</body>

</html>
