<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin - Kantin Kejujuran</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #0d6efd, #6f42c1);
      min-height: 100vh;
      margin: 0;
      color: #fff;
      overflow-x: hidden;
    }

    .glass {
      background: rgba(255, 255, 255, 0.15);
      border-radius: 16px;
      box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.18);
    }

    .sidebar {
      height: 100vh;
      padding-top: 2rem;
      position: fixed;
      width: 240px;
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(10px);
      border-right: 1px solid rgba(255, 255, 255, 0.1);
    }

    .sidebar a {
      display: block;
      padding: 12px 20px;
      color: #fff;
      font-weight: 500;
      text-decoration: none;
      transition: 0.3s;
    }

    .sidebar a:hover,
    .sidebar a.active {
      background-color: rgba(255, 255, 255, 0.15);
      border-left: 4px solid #ffc107;
    }

    .topbar {
      background: transparent;
      margin-left: 240px;
      padding: 1rem 2rem;
    }

    .main {
      margin-left: 240px;
      padding: 2rem;
    }

    .card-glass {
      border: none;
      border-radius: 16px;
      padding: 1.5rem;
      color: #fff;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(15px);
      box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
    }

    .icon {
      font-size: 2rem;
      margin-right: 1rem;
    }

    @media (max-width: 768px) {
      .sidebar {
        position: relative;
        width: 100%;
        height: auto;
      }

      .main,
      .topbar {
        margin-left: 0;
        padding: 1rem;
      }
    }
  </style>
</head>

<body>
  <div class="sidebar glass text-white">
    <h4 class="text-center mb-4">Kantin Kejujuran</h4>
    <?php $segment = $this->uri->segment(2); ?>
    <a href="<?= site_url('admin/dashboard') ?>" class="<?= $segment == '' || $segment == 'dashboard' ? 'active' : '' ?>">
      <i class="bi bi-house-door me-2"></i>Dashboard
    </a>

    <a href="<?= site_url('admin/produk') ?>" class="<?= $segment == 'produk' ? 'active' : '' ?>">
      <i class="bi bi-box me-2"></i>Produk
    </a>

    <a href="<?= site_url('admin/user') ?>" class="<?= $segment == 'user' ? 'active' : '' ?>">
      <i class="bi bi-people me-2"></i>User
    </a>

    <a href="<?= site_url('admin/laporan') ?>" class="<?= $segment == 'laporan' ? 'active' : '' ?>">
      <i class="bi bi-graph-up me-2"></i>Laporan
    </a>

    <a href="<?= site_url('auth/logout') ?>">
      <i class="bi bi-box-arrow-right me-2"></i>Logout
    </a>
  </div>

  <div class="topbar">
    <h5>Dashboard Admin</h5>
  </div>