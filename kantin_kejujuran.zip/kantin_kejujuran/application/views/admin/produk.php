<div class="main">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4>Data Produk</h4>
    <button class="btn btn-warning text-dark" data-bs-toggle="modal" data-bs-target="#tambahProdukModal">
      <i class="bi bi-plus-circle"></i> Tambah Produk
    </button>
  </div>

  <div class="glass p-3 rounded">
    <div class="table-responsive">
      <table class="table table-hover table-bordered text-white align-middle">
        <thead class="table-light text-dark">
          <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Satuan Besar</th>
            <th>Isi</th>
            <th>Harga Besar</th>
            <th>Harga Eceran</th>
            <th>Stok</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1;
          foreach ($produk as $p): ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= $p['nama_produk'] ?></td>
              <td><?= $p['banyak_satuan_besar'] ?></td>
              <td><?= $p['isi'] ?></td>
              <td>Rp <?= number_format($p['harga_satuan_besar'], 0, ',', '.') ?></td>
              <td>Rp <?= number_format($p['harga_eceran'], 0, ',', '.') ?></td>
              <td><?= $p['stok'] ?></td>
              <td>
                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editProdukModal<?= $p['id_produk'] ?>">
                  <i class="bi bi-pencil"></i>
                </button>
                <a href="<?= site_url('admin/produk/hapus/' . $p['id_produk']) ?>" onclick="return confirm('Yakin hapus?')" class="btn btn-sm btn-danger">
                  <i class="bi bi-trash"></i>
                </a>
              </td>
            </tr>

            <!-- Modal Edit Produk -->
            <div class="modal fade" id="editProdukModal<?= $p['id_produk'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <form action="<?= site_url('admin/produk/edit/' . $p['id_produk']) ?>" method="post" class="modal-content glass text-white">
                  <div class="modal-header">
                    <h5 class="modal-title">Edit Produk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <div class="mb-3">
                      <label>Nama Produk</label>
                      <input type="text" name="nama_produk" class="form-control" value="<?= $p['nama_produk'] ?>" required>
                    </div>
                    <div class="mb-3">
                      <label>Banyak Satuan Besar</label>
                      <input type="number" name="banyak_satuan_besar" class="form-control" value="<?= $p['banyak_satuan_besar'] ?>" required>
                    </div>
                    <div class="mb-3">
                      <label>Isi per Satuan Besar</label>
                      <input type="number" name="isi" class="form-control" value="<?= $p['isi'] ?>" required>
                    </div>
                    <div class="mb-3">
                      <label>Harga Satuan Besar (Rp)</label>
                      <input type="number" name="harga_satuan_besar" class="form-control" value="<?= $p['harga_satuan_besar'] ?>" required>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                  </div>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Produk -->
<div class="modal fade" id="tambahProdukModal" tabindex="-1">
  <div class="modal-dialog">
    <form action="<?= site_url('admin/produk/tambah') ?>" method="post" class="modal-content glass text-white">
      <div class="modal-header">
        <h5 class="modal-title">Tambah Produk</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label>Nama Produk</label>
          <input type="text" name="nama_produk" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Banyak Satuan Besar</label>
          <input type="number" name="banyak_satuan_besar" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Isi per Satuan Besar</label>
          <input type="number" name="isi" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Harga Satuan Besar (Rp)</label>
          <input type="number" name="harga_satuan_besar" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-warning text-dark">Tambah</button>
      </div>
    </form>
  </div>
</div>