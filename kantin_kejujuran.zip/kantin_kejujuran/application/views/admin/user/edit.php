<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        /* Gunakan gaya yang sama seperti tambah.php */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #00c6ff, #0072ff);
            margin: 0;
            color: #fff;
        }

        .sidebar {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            height: 100vh;
            padding: 1.5rem 1rem;
            position: fixed;
            top: 0;
            left: 0;
            width: 220px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .sidebar a {
            color: #fff;
            display: block;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            transition: background 0.3s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.2);
        }

        .main-content {
            margin-left: 220px;
            padding: 2rem;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            border-radius: 1rem;
            padding: 2rem;
            color: #fff;
            max-width: 600px;
        }

        label {
            font-weight: 500;
        }

        .form-control,
        .form-select {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: #fff;
        }

        .btn-submit {
            background-color: #fff;
            color: #0072ff;
            font-weight: 600;
            border: none;
        }

        .btn-submit:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="<?= site_url('dashboard') ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
        <a href="<?= site_url('produk') ?>"><i class="bi bi-box-seam me-2"></i>Produk</a>
        <a href="<?= site_url('user') ?>" class="active"><i class="bi bi-people-fill me-2"></i>User</a>
        <a href="<?= site_url('laporan') ?>"><i class="bi bi-bar-chart-fill me-2"></i>Laporan</a>
        <a href="<?= site_url('auth/logout') ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h3 class="mb-4"><i class="bi bi-pencil-square"></i> Edit User</h3>

        <div class="glass-card">
            <form method="post" action="<?= site_url('user/update/' . $user->id_user) ?>">
                <div class="mb-3">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" value="<?= $user->nama ?>" required>
                </div>
                <div class="mb-3">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" value="<?= $user->username ?>" required>
                </div>
                <div class="mb-3">
                    <label>Password (Kosongkan jika tidak diubah)</label>
                    <input type="password" name="password" class="form-control" placeholder="Password baru">
                </div>
                <div class="mb-3">
                    <label>Level</label>
                    <select name="level" class="form-select" required>
                        <option value="admin" <?= $user->level == 'admin' ? 'selected' : '' ?>>Admin</option>
                        <option value="user" <?= $user->level == 'user' ? 'selected' : '' ?>>User</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-submit"><i class="bi bi-save"></i> Update</button>
            </form>
        </div>
    </div>

</body>

</html>