<div class="main">
  <div class="row g-4">
    <div class="col-md-4">
      <div class="card-glass">
        <div class="d-flex align-items-center">
          <div class="icon"><i class="bi bi-people-fill"></i></div>
          <div>
            <h6>Total User</h6>
            <h4>25</h4>
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card-glass">
        <div class="d-flex align-items-center">
          <div class="icon"><i class="bi bi-box-seam"></i></div>
          <div>
            <h6>Total Produk</h6>
            <h4>48</h4>
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card-glass">
        <div class="d-flex align-items-center">
          <div class="icon"><i class="bi bi-graph-up-arrow"></i></div>
          <div>
            <h6>Total Transaksi</h6>
            <h4>Rp 5.200.000</h4>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="mt-5">
    <h5>Selamat Datang di Dashboard!</h5>
    <p>Gunakan menu di samping untuk mengelola produk, user, dan laporan transaksi.</p>
  </div>
</div>